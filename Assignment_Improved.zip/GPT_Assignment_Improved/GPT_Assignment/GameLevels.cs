﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using RC_Framework; 


namespace GPT_Assignment
{


    class GameLevel_0: RC_GameStateParent
    {

        SpriteFont llFont, mmFont, ssFont;
        Vector2 titleVec;
        Color titleCol; 



        public override void LoadContent()
        {

            // initialize the fonts to be used in the program
            llFont = Content.Load<SpriteFont>("Large");
            mmFont = Content.Load<SpriteFont>("Medium");
            ssFont = Content.Load<SpriteFont>("Small");

            // set the positioning of the title
            titleVec = new Vector2(225, 250);
            titleCol = new Color(15, 15, 255);

            // set up the scoring system - it is not that pretty
            // baseScore is used to compare against currScore
            // allows the levels to be switched 
            ScoreSystem.getInstance().maxScore[0, 0]  = 0;
            ScoreSystem.getInstance().maxScore[0, 1]  = 0;
            ScoreSystem.getInstance().currScore[0, 0] = 0;
            ScoreSystem.getInstance().currScore[0, 1] = 0; 

            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.DrawString(llFont, "crazy cat adventures", titleVec, titleCol); 
            spriteBatch.End();
        }


    }

    class GameLevel_1 : RC_GameStateParent
    {
        SpriteFont llFont, mmFont, ssFont;
        KeyboardState kstate, pkstate;

        ScoreSystem level1Score = ScoreSystem.getInstance(); 

        ScrollBackGround background;
        Texture2D backgroundTex;
        Rectangle backgroundRect;

        SoundEffect success;
        SoundEffect kaching;
        SoundEffect yowling;
        SoundEffect jumping;

        LimitSound successSound;
        LimitSound kachingSound;
        LimitSound yowlingSound;
        LimitSound jumpingSound;



        // player is the cute little kitty cat
        Sprite3 playerSprite;
        Texture2D playerTex;
        Vector2 playerVec;
        Vector2 playerPrevPos; 
        Vector2[] playerFrames;

        bool playerJump;
        float playerJumpSpeed;


        Random random = new Random(); 
        SpriteList yarnBallList;
        Sprite3 yarnBall;
        Texture2D yarnTex;
        Vector2 yarnVec;

        bool showBB = false;

        int tempPointScore = 0;
        int tempLifeScore = 1; 
        

        public override void LoadContent()
        {
            // initialize the fonts to be used in the program
            llFont = Content.Load<SpriteFont>("Large");
            mmFont = Content.Load<SpriteFont>("Medium");
            ssFont = Content.Load<SpriteFont>("Small");

            // set up the scoring system for this level 

            level1Score.SetMaxPointScore(12, 1);
            level1Score.SetMaxLifeScore(1, 1);
            level1Score.SetLives(tempLifeScore, 1);
            level1Score.SetPoints(tempPointScore, 1);


            // set up the background 
            backgroundRect = new Rectangle(0, 0, 800, 600); 
            backgroundTex = Content.Load<Texture2D>("Background");
            background = new ScrollBackGround(backgroundTex, backgroundRect, backgroundRect, 2.5f, 2);

            // set up the cute little kitty cat 
            playerVec = new Vector2(600, 400);
            playerPrevPos = new Vector2(); 
            playerFrames = new Vector2[10]; 
            playerTex = Content.Load<Texture2D>("KittyCatFrames");
            playerSprite = new Sprite3(true, playerTex, playerVec.X, playerVec.Y);

            playerFrames[0].X = 0;      playerFrames[0].Y = 0;
            playerFrames[1].X = 1 ;     playerFrames[1].Y = 0;
            playerFrames[2].X = 2;      playerFrames[2].Y = 0;
            playerFrames[3].X = 3;      playerFrames[3].Y = 0;
            playerFrames[4].X = 4;      playerFrames[4].Y = 0; 
            playerFrames[5].X = 5;      playerFrames[5].Y = 0; 
            playerFrames[6].X = 6;      playerFrames[6].Y = 0; 
            playerFrames[7].X = 7;      playerFrames[7].Y = 0; 
            playerFrames[8].X = 8;      playerFrames[8].Y = 0;
            playerFrames[9].X = 9;      playerFrames[9].Y = 0;

            playerSprite.setWidthHeight(64, 64);
            playerSprite.setWidthHeightOfTex(1280, 128);
            playerSprite.setMoveSpeed(3.5f); 
            playerSprite.setXframes(10);
            playerSprite.setYframes(0);
            playerSprite.setBB(0, 0, 128, 128);
            playerSprite.setAnimationSequence(playerFrames, 0, 9, 10);
            playerSprite.animationStart();

            playerJump = false;
            playerJumpSpeed = 0;

            // this holds the initial position of the cute little kitty cat
            // for if he jumps up or down the screen 
            playerPrevPos.X = playerVec.X;
            playerPrevPos.Y = playerVec.Y;

            // we now add yarn balls to the game
            yarnBallList = new SpriteList(); 
            yarnTex = Content.Load<Texture2D>("Yarn");
            yarnVec = new Vector2(0, 400);

                for (int i = 0; i < 245; i++)
                {

                    yarnVec.X += i * 2;
                yarnVec.Y -= i * i; 

                    yarnBall = new Sprite3(true, yarnTex, yarnVec.X, yarnVec.Y);

                    yarnBall.setDeltaSpeed(new Vector2((float)(1 + random.NextDouble()), 0));
                    yarnBall.setWidthHeight(32, 32);
                    yarnBall.setWidthHeightOfTex(32, 32);
                    yarnBall.setHSoffset(new Vector2(32, 32));
                    yarnBall.setBBToTexture();
                    yarnBall.setMoveSpeed(5.1f);
                    yarnBallList.addSprite(yarnBall);
                }

            // load the sounds for this level 

            success = Content.Load<SoundEffect>("Success");
            kaching = Content.Load<SoundEffect>("Kaching");
            yowling = Content.Load<SoundEffect>("Yowl");
            jumping = Content.Load<SoundEffect>("Boing");

            successSound = new LimitSound(success, 1);
            kachingSound = new LimitSound(kaching, 1);
            yowlingSound = new LimitSound(yowling, 1);
            jumpingSound = new LimitSound(jumping, 1); 

            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {

            pkstate = kstate;
            kstate = Keyboard.GetState();


            yarnBallList.moveDeltaXY();

         
            

            for(int i=0; i< yarnBallList.count(); i++)
            {
                Sprite3 s = yarnBallList.getSprite(i);
                bool coll = playerSprite.collision(s);

                if(coll)
                {
                    kachingSound.playSoundIfOk();
                    tempPointScore++;

                    ScoreSystem.getInstance().SetPoints(tempPointScore, 1); 
                    s.setActive(false);
                    
                }
                // repeat the flow of yarn balls 
                if (s.getPosX() > 800)
                {
                    s.setPosX(0);
                }


            }

           


            if (kstate.IsKeyDown(Keys.Left))
            {
                playerSprite.moveByDeltaXY();
                playerSprite.animationTick(gameTime);
                playerSprite.active = true;
                successSound.playSoundIfOk(); 
                background.Update(gameTime); 
            }

            if(kstate.IsKeyDown(Keys.B) && pkstate.IsKeyUp(Keys.B)) 
            {
                // this activates the bounding box for the player
                showBB = !showBB; 
            }

            if(kstate.IsKeyDown(Keys.Z))
            {
                playerJumpSpeed++;
            }

            if (kstate.IsKeyDown(Keys.X))
            {
                playerJumpSpeed--; 
            }

      

            // the code to help the cute little kitty cat to jump

            if (playerJump)
            {
                playerVec.Y += playerJumpSpeed;
                playerJumpSpeed += 1;
                playerSprite.setPosY(playerVec.Y);

                if (playerVec.Y >= playerPrevPos.Y)
                {
                    playerSprite.setPosY(playerPrevPos.Y);
                    playerJump = false; 
                }

            } else
            {
                if (kstate.IsKeyDown(Keys.Up))
                {
                    playerJump = true;
                    playerJumpSpeed = -14;
                    jumpingSound.playSoundIfOk(); 
                    playerSprite.setPosY(playerVec.Y); 
                }
            }


            base.Update(gameTime);
        }
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            background.Draw(spriteBatch);
            playerSprite.Draw(spriteBatch);


            if (showBB)
            {
                playerSprite.drawBB(spriteBatch, Color.Red);
                yarnBallList.drawInfo(spriteBatch, Color.Red, Color.Red);
            }


            yarnBallList.Draw(spriteBatch); 
            spriteBatch.DrawString(llFont, "Level 1", new Vector2(100, 100), Color.Gold);
            spriteBatch.End();



        }
    }

    class GameLevel_2 : RC_GameStateParent
    {
        SpriteFont llFont, mmFont, ssFont;
        ScrollBackGround background;
        Texture2D backgroundTex;
        Rectangle backgroundRect;

        KeyboardState kstate, pkstate; 

        Sprite3 playerSprite;
        Texture2D playerTex;
        Vector2 playerVec;
        Vector2 prevPlayerPosVec; 
        Vector2[] playerFrames;

        Sprite3 crazyDogSprite;
        Texture2D crazyDogTex;
        Vector2 crazyDogVec;
        Vector2[] crazyDogFrames;

        bool showBB = false;

        bool collCrazyDog; 


        bool playerJump;
        float playerJumpSpeed; 


        int tempLifeScore = 2;
        int tempPointScore = 0;

        SoundEffect kaching;
        SoundEffect boing;
        SoundEffect growl;
        SoundEffect yowl;
        SoundEffect success; 

        LimitSound kachingSound;
        LimitSound boingSound;
        LimitSound growlSound;
        LimitSound yowlSound;
        LimitSound successSound;


        public override void LoadContent()
        {
            // initialize the fonts to be used in the program
            llFont = Content.Load<SpriteFont>("Large");
            mmFont = Content.Load<SpriteFont>("Medium");
            ssFont = Content.Load<SpriteFont>("Small");

            // set up the scoring system for this level 
            ScoreSystem.getInstance().maxScore[2, 0] = 5;      // point score
            ScoreSystem.getInstance().maxScore[2, 1] = 2;      // life score
            ScoreSystem.getInstance().currScore[2, 0] = tempPointScore;
            ScoreSystem.getInstance().currScore[2, 1] = tempLifeScore;

            // set up the textures for this level 
            playerTex = Content.Load<Texture2D>("KittyCatFrames");
            crazyDogTex = Content.Load<Texture2D>("CrazyDogFrames");
            backgroundTex = Content.Load<Texture2D>("Background");

            // set up the sprite init positioning
            playerVec = new Vector2(650, 400);
            crazyDogVec = new Vector2(50, 400);
            backgroundRect = new Rectangle(0, 0, 800, 600);


            prevPlayerPosVec = new Vector2();

            prevPlayerPosVec.X = playerVec.X;
            prevPlayerPosVec.Y = playerVec.Y; 

            // set up the background for this level
            background = new ScrollBackGround(backgroundTex, backgroundRect, backgroundRect, 1.0f, 2);

            // set up the sprites for this level
            playerSprite = new Sprite3(true, playerTex, playerVec.X, playerVec.Y);
            crazyDogSprite = new Sprite3(true, crazyDogTex, crazyDogVec.X, crazyDogVec.Y);

            // set up the frame based animation for each sprite
            playerFrames = new Vector2[10]; crazyDogFrames = new Vector2[10];

            playerFrames[0].X = 0;  playerFrames[0].Y = 0;
            playerFrames[1].X = 1;  playerFrames[1].Y = 0;
            playerFrames[2].X = 2;  playerFrames[2].Y = 0;
            playerFrames[3].X = 3;  playerFrames[3].Y = 0;
            playerFrames[4].X = 4;  playerFrames[4].Y = 0;
            playerFrames[5].X = 5;  playerFrames[5].Y = 0;
            playerFrames[6].X = 6;  playerFrames[6].Y = 0;
            playerFrames[7].X = 7;  playerFrames[7].Y = 0;
            playerFrames[8].X = 8;  playerFrames[8].Y = 0;
            playerFrames[9].X = 9;  playerFrames[9].Y = 0;


            crazyDogFrames[0].X = 0; crazyDogFrames[0].Y = 0;
            crazyDogFrames[1].X = 1; crazyDogFrames[1].Y = 0; 
            crazyDogFrames[2].X = 2; crazyDogFrames[2].Y = 0;
            crazyDogFrames[3].X = 3; crazyDogFrames[3].Y = 0;
            crazyDogFrames[4].X = 4; crazyDogFrames[4].Y = 0;
            crazyDogFrames[5].X = 5; crazyDogFrames[5].Y = 0;
            crazyDogFrames[6].X = 6; crazyDogFrames[6].Y = 0;
            crazyDogFrames[7].X = 7; crazyDogFrames[7].Y = 0;
            crazyDogFrames[8].X = 8; crazyDogFrames[8].Y = 0;
            crazyDogFrames[9].X = 9; crazyDogFrames[9].Y = 0;

            playerSprite.setWidthHeight(64, 64);
            playerSprite.setWidthHeightOfTex(1280, 128);
            playerSprite.setXframes(10);
            playerSprite.setYframes(0);
            playerSprite.setBB(0, 0, 128, 128);
            playerSprite.setAnimationSequence(playerFrames, 0, 9, 15);
            playerSprite.animationStart();

            crazyDogSprite.setWidthHeight(64, 64);
            crazyDogSprite.setWidthHeightOfTex(1024, 128);
            crazyDogSprite.setXframes(8);
            crazyDogSprite.setYframes(0);
            crazyDogSprite.setBB(0, 0, 128, 128);
            crazyDogSprite.setAnimationSequence(crazyDogFrames, 0, 7, 15);
            crazyDogSprite.animationStart();

            // jumping variables for the kitty cat
            playerJump = false;
            playerJumpSpeed = 0;

            // sounds
            kaching = Content.Load<SoundEffect>("Kaching");
            yowl = Content.Load<SoundEffect>("Yowl");
            growl = Content.Load<SoundEffect>("Growl");
            boing = Content.Load<SoundEffect>("Boing");
            success = Content.Load<SoundEffect>("Success");

            kachingSound = new LimitSound(kaching, 1);
            yowlSound = new LimitSound(yowl, 1);
            growlSound = new LimitSound(growl, 1);
            boingSound = new LimitSound(boing, 1);
            successSound = new LimitSound(success, 1); 
        


            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {
            pkstate = kstate;
            kstate = Keyboard.GetState();

            // set up the crazy dog
            crazyDogSprite.setVisible(true);
            //crazyDogSprite.moveByDeltaXY();
            crazyDogSprite.animationTick(gameTime);
            crazyDogSprite.setActive(true);

            crazyDogVec.X++;
            crazyDogSprite.setPosX(crazyDogVec.X);

            if (crazyDogSprite.getPosX() > 800) crazyDogVec.X = 0;

            if (crazyDogSprite.getPosX() == 100 || crazyDogSprite.getPosX() == 400) growlSound.playSoundIfOk(); 

            collCrazyDog = playerSprite.collision(crazyDogSprite);


            // what happens if the collision takes place 
            if(collCrazyDog == true && crazyDogVec.X == playerVec.X)
            {
                tempLifeScore--;
                yowlSound.playSoundIfOk(); 
                ScoreSystem.getInstance().SetLives(tempLifeScore, 2);
            }
           
            if(collCrazyDog == false && crazyDogVec.X == playerVec.X)
            {
                tempPointScore++;
                kachingSound.playSoundIfOk(); 
                ScoreSystem.getInstance().SetPoints(tempPointScore, 2); 
            }



            if (kstate.IsKeyDown(Keys.Left))
            {
                playerSprite.moveByDeltaXY();
                playerSprite.animationTick(gameTime);
                successSound.playSoundIfOk();
                playerSprite.active = true;
                background.Update(gameTime);
            } 

            if(kstate.IsKeyDown(Keys.B) && pkstate.IsKeyUp(Keys.B))
            {
                showBB = !showBB; 
            }


            if(kstate.IsKeyDown(Keys.Z))
            {
                playerJumpSpeed++;
            }

            if(kstate.IsKeyDown(Keys.X))
            {
                playerJumpSpeed--; 
            }

            // what happens when the player sprite is jumping

            if(playerJump)
            {
                playerVec.Y += playerJumpSpeed;
                playerJumpSpeed += 1;
                playerSprite.setPosY(playerVec.Y);

                if(playerVec.Y >= prevPlayerPosVec.Y)
                {
                    playerSprite.setPosY(prevPlayerPosVec.Y);
                    playerJump = false;
                }
            } else
            {
                if (kstate.IsKeyDown(Keys.Up))
                {
                    playerJump = true;
                    playerJumpSpeed = -14;
                    boingSound.playSoundIfOk(); 
                    playerSprite.setPosY(playerVec.Y);
                }
            }


            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            background.Draw(spriteBatch);
            crazyDogSprite.Draw(spriteBatch);
            playerSprite.Draw(spriteBatch);
            spriteBatch.End();
        }
    }

    //class GameLevel_1 : RC_GameStateParent
    //{
    //    // this is a splash screen level for the first level 
    //    SpriteFont llFont;
    //    Color lcol;
    //    int ticks;
    //    public bool complete; 
    //    public override void LoadContent()
    //    {
    //        llFont = Content.Load<SpriteFont>("Large");
    //        lcol = new Color(15, 15, 255, 1);
    //        ticks = 0; 
    //        base.LoadContent();
    //    }

    //    public override void Update(GameTime gameTime)
    //    {
    //        ticks++;

    //        if (ticks == 100) complete = true; 

    //        base.Update(gameTime);
    //    }
    //    public override void Draw(GameTime gameTime)
    //    {
    //        spriteBatch.Begin();
    //        spriteBatch.DrawString(llFont, "Level 1", new Vector2(300, 300), lcol); 
    //        spriteBatch.End(); 
    //    }
    //}

    //class GameLevel_3 : RC_GameStateParent
    //{
    //    // this is a splash screen level for the first level 
    //    SpriteFont llFont;
    //    Color lcol;
    //    int ticks; 

    //    public override void LoadContent()
    //    {
    //        llFont = Content.Load<SpriteFont>("Large");
    //        lcol = new Color(15, 15, 255, 1);
    //        ticks = 0; 

    //        base.LoadContent();
    //    }

    //    public override void Update(GameTime gameTime)
    //    {
    //        ticks++;

    //        if (ticks == 125) gameStateManager.pushLevel(3); 
    //        base.Update(gameTime);
    //    }
    //    public override void Draw(GameTime gameTime)
    //    {
    //        spriteBatch.Begin();
    //        spriteBatch.DrawString(llFont, "Level 2", new Vector2(250, 200), lcol);
    //        spriteBatch.End();
    //    }
    //}

}

﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using RC_Framework;
using System;

namespace GPT_Assignment
{

    public class ScoreSystem
    {
        public int[,] maxScore; 
        public static ScoreSystem instance = new ScoreSystem();
        public int[,] currScore;


        public static ScoreSystem getInstance()
        {
            if(instance == null) { 
                instance = new ScoreSystem(); 
            }

            return instance; 
        }

        public bool MaxPoints(int level)
        {
            if (currScore[level, 0] == maxScore[level, 0])
            {
                return true;
            } 

            return false; 
        }

        public bool MaxLives(int level)
        {
            if(currScore[level, 1] == 0)
            {
                return true;
            }
            return false; 
        }

        // set the max score 
        public void SetMaxPointScore(int score, int level)
        {
            maxScore[level, 0] = score;
        }

        public void SetMaxLifeScore(int score, int level)
        {
            maxScore[level, 1] = score; 
        }

        public int GetMaxPointScore(int level)
        {
            return maxScore[level, 0];
        }

        public int GetMaxLifeScore(int level)
        {
            return maxScore[level, 1];
        }



        // updating on a regular basis 
        public void SetPoints(int score, int level)
        {
            currScore[level, 0] = score; 
        }

        public int GetPoints(int level)
        {
            return currScore[level, 0];
        }

        public void SetLives(int score, int level)
        {
            currScore[level, 1] = score; 
        }

        public int GetLives(int level)
        {
            return currScore[level, 1]; 
        }

    }


    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        RC_GameStateManager levelManager;
        KeyboardState keyState, prevKeyState; 

        SpriteFont ssFont;

        bool showFF = false; 
        bool showSS = false; 
        bool showHH = false;
        bool showII = false;

        string splashScreenMsg = ""; 

        Color ssCol = new Color(200, 0, 0, 1); 
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = 800;
            graphics.PreferredBackBufferHeight = 600;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            LineBatch.init(GraphicsDevice);

            // set up the sole font for the help box and the info box
            ssFont = Content.Load<SpriteFont>("Small");

            // set up the base score system 
            ScoreSystem.getInstance().maxScore = new int[3,2];
            ScoreSystem.getInstance().currScore = new int[3, 2]; 


            // set up the levels for the game 
            levelManager = new RC_GameStateManager();

            levelManager.AddLevel(0, new GameLevel_0());
            levelManager.getLevel(0).InitializeLevel(GraphicsDevice, spriteBatch, Content, levelManager);
            levelManager.getLevel(0).LoadContent();
            levelManager.setLevel(0);

            levelManager.AddLevel(1, new GameLevel_1()); 
            levelManager.getLevel(1).InitializeLevel(GraphicsDevice, spriteBatch, Content, levelManager);
            levelManager.getLevel(1).LoadContent();

            levelManager.AddLevel(2, new GameLevel_2());
            levelManager.getLevel(2).InitializeLevel(GraphicsDevice, spriteBatch, Content, levelManager);
            levelManager.getLevel(2).LoadContent();




        }



        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            prevKeyState = keyState; 
            keyState = Keyboard.GetState();

            showSS = false; 

            if(keyState.IsKeyDown(Keys.D1) || keyState.IsKeyDown(Keys.S))
            {
                levelManager.setLevel(1);
           

            } else if(keyState.IsKeyDown(Keys.D2))
            {
                levelManager.setLevel(2);

            } else if(keyState.IsKeyDown(Keys.H) && prevKeyState.IsKeyUp(Keys.H))
            {
                showHH = !showHH; 
            } else if (keyState.IsKeyDown(Keys.I) && prevKeyState.IsKeyUp(Keys.I))
            {
                showII = !showII; 
            }

            // at a later point I might look into cleaning up this code - it looks ugly 
         

            if (ScoreSystem.getInstance().MaxPoints(1))
            {
                levelManager.setLevel(2); 
            }

            if (ScoreSystem.getInstance().MaxLives(2))
            {
                levelManager.setLevel(0);
            }

            if (ScoreSystem.getInstance().MaxPoints(2))
            {
                levelManager.setLevel(0); 
            }

            


            levelManager.getCurrentLevel().Update(gameTime); 

            base.Update(gameTime);
        }


        public void DrawSS(GameTime gameTime, bool visible, string msg)
        {
            spriteBatch.Begin();
            if (visible)
            {
                spriteBatch.DrawString(ssFont, msg, new Vector2(250, 250), ssCol);
            }
            spriteBatch.End();
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);


            levelManager.getCurrentLevel().Draw(gameTime);



            if (showHH) DrawHH(gameTime);
            if (showII && levelManager.getCurrentLevelNum() != 0) DrawII(gameTime);

            base.Draw(gameTime);
        }

        protected void DrawHH(GameTime gameTime)
        {

            spriteBatch.Begin();
            spriteBatch.DrawString(ssFont, "KEYBOARD OPTIONS", new Vector2(50, 50), Color.Gold);
            spriteBatch.DrawString(ssFont, "H - toggle help", new Vector2(50, 65), Color.Gold);
            spriteBatch.DrawString(ssFont, "S - start game", new Vector2(50, 80), Color.Gold);
            spriteBatch.DrawString(ssFont, "1/2 - levels 1 or 2", new Vector2(50, 95), Color.Gold);
            spriteBatch.DrawString(ssFont, "Right - move right", new Vector2(50, 110), Color.Gold);
            spriteBatch.DrawString(ssFont, "Left - move left", new Vector2(50, 125), Color.Gold);
            spriteBatch.DrawString(ssFont, "Up - jump", new Vector2(50, 140), Color.Gold);
            spriteBatch.DrawString(ssFont, "Space - pounce", new Vector2(50, 155), Color.Gold);
            spriteBatch.DrawString(ssFont, "B - show bounding boxes", new Vector2(50, 170), Color.Gold);
            spriteBatch.End();

        }

        protected void DrawII(GameTime gameTime)
        {

            // show information if the user requests it
            spriteBatch.Begin();
            spriteBatch.DrawString(ssFont, "Level " + levelManager.getCurrentLevelNum(), new Vector2(650, 50), Color.White);
            spriteBatch.DrawString(ssFont, "Points : " + ScoreSystem.getInstance().GetPoints(levelManager.getCurrentLevelNum())   , new Vector2(650, 65), Color.White);
            spriteBatch.DrawString(ssFont, "Lives : " + ScoreSystem.getInstance().GetLives(levelManager.getCurrentLevelNum()), new Vector2(650, 80), Color.White); 
            spriteBatch.End();


        }
    }
}
